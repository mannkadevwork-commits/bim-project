import { Texture } from '@xeokit/xeokit-sdk/src/viewer/scene/materials/Texture';
import { PhongMaterial } from '@xeokit/xeokit-sdk/src/viewer/scene/materials/PhongMaterial';

const rgbFallback = [1, 1, 1];

export const normalizeMaterialDefinition = (definition) => ({
  kind: ['color', 'fabric', 'texture'].includes(definition?.kind) ? definition.kind : 'color',
  color: definition?.color || '#FFFFFF',
  rgb: Array.isArray(definition?.rgb) ? definition.rgb : rgbFallback,
  texture: ['fabric', 'texture'].includes(definition?.kind) && (definition?.textureSrc || definition?.texture?.src)
    ? {
        id: definition.textureId || definition.texture?.id || definition.id || null,
        name: definition.name || definition.texture?.name || (definition.kind === 'fabric' ? 'Fabric' : 'Texture'),
        src: definition.textureSrc || definition.texture?.src,
        repeat: Array.isArray(definition.repeat)
          ? definition.repeat
          : (Array.isArray(definition.texture?.repeat) ? definition.texture.repeat : [2, 2]),
      }
    : null,
  roughness: Number.isFinite(definition?.roughness) ? definition.roughness : 0.8,
  metallic: Number.isFinite(definition?.metallic) ? definition.metallic : 0,
});

const resolveTargetObjects = (viewer, targetId) => {
  if (!viewer || !targetId) return [];
  const targets = [];
  const direct = viewer.scene?.objects?.[targetId];
  if (direct) targets.push(direct);
  const model = viewer.scene?.models?.[targetId];
  if (model) {
    Object.values(viewer.scene.objects || {}).forEach((object) => {
      if (object?.model?.id === targetId) targets.push(object);
    });
  }
  return Array.from(new Set(targets));
};

const loadImage = (src) => new Promise((resolve, reject) => {
  if (!src) return reject(new Error('Material texture source is missing'));
  const image = new Image();
  image.crossOrigin = 'anonymous';
  image.onload = () => resolve(image);
  image.onerror = () => reject(new Error(`Failed to load material texture: ${src}`));
  image.src = src;
});

const clearXeokitSpinnerForMaterialAction = (viewer) => {
  // Material changes are not model loads. xeokit's Canvas Spinner can remain
  // visible when a texture request was interrupted; close only the viewer's
  // material-action residue after the operation settles.
  try {
    const spinner = viewer?.scene?.canvas?.spinner;
    if (spinner && spinner.processes > 0) spinner.processes = 0;
  } catch (_) {}
};

export const applyMaterialDefinitionToSceneTarget = async (viewer, targetId, definition) => {
  if (!viewer || !targetId || !definition) return false;
  const materialDef = normalizeMaterialDefinition(definition);
  const targets = resolveTargetObjects(viewer, targetId);
  if (!targets.length) return false;

  try {
    let diffuseMap = null;
    if (materialDef.texture?.src) {
      const image = await loadImage(materialDef.texture.src);
      diffuseMap = new Texture(viewer.scene, {
        image,
        scale: materialDef.texture.repeat || [1, 1],
      });
    }

    const materialOptions = {
      diffuse: materialDef.rgb,
      emissive: [0, 0, 0],
      shininess: Math.max(8, Math.round((1 - materialDef.roughness) * 100)),
    };
    if (diffuseMap) materialOptions.diffuseMap = diffuseMap;

    const material = new PhongMaterial(viewer.scene, materialOptions);
    targets.forEach((object) => {
      try {
        const previous = object.material;
        object.material = material;
        if (previous && previous !== material && previous._hciOwned) {
          try { previous.destroy(); } catch (_) {}
        }
        material._hciOwned = true;
      } catch (_) {}
      try { object.colorize = materialDef.texture ? [1, 1, 1] : materialDef.rgb; } catch (_) {}
    });

    clearXeokitSpinnerForMaterialAction(viewer);
    return true;
  } catch (error) {
    console.warn('[Material] Texture load failed; applying color fallback.', error);
    const fallback = new PhongMaterial(viewer.scene, {
      diffuse: materialDef.rgb,
      emissive: [0, 0, 0],
      shininess: Math.max(8, Math.round((1 - materialDef.roughness) * 100)),
    });
    targets.forEach((object) => {
      try {
        const previous = object.material;
        object.material = fallback;
        if (previous && previous !== fallback && previous._hciOwned) {
          try { previous.destroy(); } catch (_) {}
        }
        fallback._hciOwned = true;
      } catch (_) {}
      try { object.colorize = materialDef.rgb; } catch (_) {}
    });
    clearXeokitSpinnerForMaterialAction(viewer);
    return false;
  }
};

export const applyMaterialDefinitionToObjects = async (viewer, targetIds, definition) => {
  const results = await Promise.all((targetIds || []).map((id) => applyMaterialDefinitionToSceneTarget(viewer, id, definition)));
  clearXeokitSpinnerForMaterialAction(viewer);
  return results;
};

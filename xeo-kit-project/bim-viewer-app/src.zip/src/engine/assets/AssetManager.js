import { API_BASE_URL } from '../utils/constants';
import { perfFetch, perfLog, perfTimer } from '../../utils/perfLogger';
import {
  applyGLBPlacementTransform,
  buildGLBNormalization,
  GLB_TRANSFORM_VERSION,
  getGLBPlacementTarget,
  isValidMatrix16,
  migrateLegacyGLBTransform,
  sanitizeRotation,
  sanitizeScale,
} from './GLBAssetTransform';
import { inspectGLBSource } from './GLBAssetDescriptor';
import { ensureIFCResizeMetadata } from '../stretch/IFCResizeController';

const nativeIsolationInFlight = new Set();

const createAssetReadySignal = (instanceId, assetFormat, timeoutMs = 45000) => {
  let resolve;
  let reject;
  let settled = false;
  let timeoutId = null;
  const promise = new Promise((resolvePromise, rejectPromise) => {
    resolve = resolvePromise;
    reject = rejectPromise;
    timeoutId = setTimeout(() => {
      if (settled) return;
      settled = true;
      rejectPromise(new Error(`${assetFormat.toUpperCase()} asset "${instanceId}" did not finish loading within ${timeoutMs}ms.`));
    }, timeoutMs);
  });
  // Attach a handler immediately so a failed loader doesn't create an
  // unhandled rejection when a caller only needs the SceneModel handle.
  promise.catch(() => {});
  const finish = (callback, value) => {
    if (settled) return;
    settled = true;
    if (timeoutId) clearTimeout(timeoutId);
    callback(value);
  };
  return {
    promise,
    resolve: (value) => finish(resolve, value),
    reject: (error) => finish(reject, error instanceof Error ? error : new Error(String(error || 'Asset load failed.'))),
  };
};

// IMPORTANT: loadIFCAssetIntoScene can be called from two independent paths:
// 1) the live catalog placement path, and
// 2) projectState restoration.
// React state updates can cause both paths to request the same instanceId before
// either caller knows that the other one has already created a SceneModel.
// Keep one registry per loader instance so the same asset instance can never
// create two SceneModels during that race.
const loadedAssetModelsByLoader = new WeakMap();

const getAssetRegistry = (loader) => {
  let registry = loadedAssetModelsByLoader.get(loader);
  if (!registry) {
    registry = new Map();
    loadedAssetModelsByLoader.set(loader, registry);
  }
  return registry;
};

const getLiveRegisteredModel = (registry, instanceId) => {
  const model = registry.get(instanceId);
  if (!model) return null;

  // SceneModel exposes `destroyed` in xeokit releases where the component
  // lifecycle flag is available. Also verify the id so a stale entry can never
  // be returned for a different model.
  if (model.id !== instanceId || model.destroyed === true) {
    registry.delete(instanceId);
    return null;
  }

  return model;
};

const resolveAssetFormat = (srcUrl, options = {}) => {
  const explicit = String(
    options.assetFormat ||
    options.fileType ||
    options.file_type ||
    ''
  ).trim().toLowerCase();

  if (explicit === 'glb' || explicit === 'gltf') return 'glb';
  if (explicit === 'ifc') return 'ifc';

  const cleanSrc = String(srcUrl || '').split('?')[0].split('#')[0].toLowerCase();
  if (cleanSrc.endsWith('.glb') || cleanSrc.endsWith('.gltf')) return 'glb';

  return 'ifc';
};

export const loadIFCAssetIntoScene = async (
  loadersRef,
  globalScaleFactorRef,
  instanceId,
  srcUrl,
  targetPosition,
  rotation,
  options = {}
) => {
  const assetFormat = resolveAssetFormat(srcUrl, options);
  const loader = assetFormat === 'glb'
    ? loadersRef.current.gltf
    : loadersRef.current.ifc;

  if (!loader) {
    if (assetFormat === 'glb') {
      throw new Error('GLTF loader is not initialized.');
    }
    return null;
  }

  // Idempotency guard: if another code path already created this instance, reuse
  // that exact SceneModel instead of creating another one.
  const registry = getAssetRegistry(loader);
  const existingModel = getLiveRegisteredModel(registry, instanceId);
  if (existingModel) {
    return existingModel._hciAssetReadyPromise || existingModel;
  }

  if (assetFormat === 'glb') {
    try {
      const assetLoadEnd = perfTimer('ASSET', `load GLB ${instanceId}`, { instanceId, srcUrl });
      const assetModel = loader.load({
        id: instanceId,
        src: srcUrl,
        edges: false,
        // Respect glTF material.doubleSided instead of forcing all backfaces.
        // This avoids visible interior/back-side triangles on furniture shells.
        backfaces: false,
        pbrEnabled: true,
        colorTextureEnabled: true,
      });
      const readySignal = createAssetReadySignal(instanceId, 'glb');
      assetModel._hciAssetReadyPromise = readySignal.promise;

      // Register IMMEDIATELY after loader.load(). The model can still be loading;
      // that is exactly the window in which restoreProjectStateToScene may race
      // with a live drag/drop request.
      registry.set(instanceId, assetModel);

      const descriptorPromise = inspectGLBSource(srcUrl).catch((error) => {
        console.warn('[BIM Engine] GLB source inspection unavailable; using runtime fallback:', {
          instanceId,
          srcUrl,
          error: error?.message || String(error),
        });
        return null;
      });

      assetModel._assetMeta = {
        instanceId,
        fileType: 'glb',
        assetFormat: 'glb',
        srcUrl,
        assetCategory: options.assetCategory || null,
        isLightFixture: options.isLightFixture === true || options.assetCategory === 'lighting',
        lightEnabled: options.lightEnabled === true,
        lightIntensity: Number.isFinite(Number(options.lightIntensity)) ? Number(options.lightIntensity) : 0.12,
        lightTemperature: Number.isFinite(Number(options.lightTemperature)) ? Number(options.lightTemperature) : 4000,
      };

      const applyLoadedTransform = async () => {
        try {
          const sourceDescriptor = await descriptorPromise;
          const existingNormalization = options.glbNormalization;
          const normalization = existingNormalization?.version === GLB_TRANSFORM_VERSION
            ? {
                ...existingNormalization,
                version: GLB_TRANSFORM_VERSION,
                pivotLocal: Array.isArray(existingNormalization.pivotLocal)
                  ? [...existingNormalization.pivotLocal]
                  : buildGLBNormalization(assetModel).pivotLocal,
              }
            : buildGLBNormalization(assetModel, {
                pivotMode: options.pivotMode,
                pivotLocal: options.pivotLocal,
                unitScale: options.unitScale,
                descriptor: sourceDescriptor,
              });

          assetModel._assetMeta.glbNormalization = normalization;
          assetModel._assetMeta.glbNormalized = true;
          assetModel._assetMeta.assetDimensions = [...normalization.dimensions];

          const legacyMatrix = isValidMatrix16(options.persistedMatrix)
            ? options.persistedMatrix
            : null;

          const userScale = sanitizeScale(options.scale || [1, 1, 1]);
          const safeRotation = sanitizeRotation(rotation);
          let semanticTarget = Array.isArray(targetPosition) && targetPosition.length === 3
            ? [...targetPosition]
            : null;

          if (!semanticTarget && legacyMatrix) {
            semanticTarget = migrateLegacyGLBTransform(
              assetModel,
              legacyMatrix,
              safeRotation,
              userScale
            );
          }

          if (!semanticTarget) {
            semanticTarget = getGLBPlacementTarget(assetModel);
          }

          applyGLBPlacementTransform(
            assetModel,
            semanticTarget,
            safeRotation,
            userScale
          );

          if (typeof options.onLoaded === 'function') {
            options.onLoaded(assetModel);
          }
        } catch (error) {
          readySignal.reject(error);
          registry.delete(instanceId);
          assetLoadEnd({ loaded: false, format: 'glb', error: error?.message || String(error) });
          console.error('[BIM Engine] GLB normalization/placement failure:', {
            instanceId,
            srcUrl,
            error,
          });
          // The readiness promise carries this failure to every awaiting caller;
          // do not leak a second unhandled rejection from the event callback.
          return;
        }

        assetLoadEnd({ loaded: true, format: 'glb', modelId: assetModel.id });
        perfLog('ASSET', 'GLB model loaded', { instanceId, modelId: assetModel.id, srcUrl });

        if (typeof options.onPlaced === 'function') {
          const persistedTarget = getGLBPlacementTarget(assetModel);
          options.onPlaced(instanceId, persistedTarget, assetModel);
        }
        readySignal.resolve(assetModel);
      };

      assetModel.on('loaded', applyLoadedTransform);
      assetModel.on('error', (error) => {
        readySignal.reject(error || new Error(`Failed to load GLB asset "${instanceId}".`));
        registry.delete(instanceId);
        assetLoadEnd({ loaded: false, format: 'glb', error: error?.message || String(error) });
        console.error('[BIM Engine] GLB asset load failure:', {
          instanceId,
          srcUrl,
          error,
        });
      });

      return assetModel._hciAssetReadyPromise;
    } catch (error) {
      registry.delete(instanceId);
      console.error('[BIM Engine] GLB placement failure:', {
        instanceId,
        srcUrl,
        error,
      });
      throw error;
    }
  }

  const assetLoadEnd = perfTimer('ASSET', `load IFC ${instanceId}`, { instanceId, srcUrl });

  try {
    const response = await perfFetch('ASSET', `IFC ${instanceId}`, srcUrl);
    if (!response.ok) throw new Error(`Asset fetch failed (${response.status})`);

    const bufferTimer = perfTimer('ASSET', `decode IFC response ${instanceId}`);
    const buffer = await response.arrayBuffer();
    bufferTimer({ bytes: buffer.byteLength });

    const assetModel = loader.load({
      id: instanceId,
      ifc: new Uint8Array(buffer),
      edges: true,
      globalizeCoordinates: false,
    });
    const readySignal = createAssetReadySignal(instanceId, 'ifc');
    assetModel._hciAssetReadyPromise = readySignal.promise;

    // Register immediately, before the IFC model's async `loaded` event.
    registry.set(instanceId, assetModel);

    assetModel._assetMeta = {
      instanceId,
      fileType: 'ifc',
      assetFormat: 'ifc',
      srcUrl,
      // Keep lighting metadata consistent with the GLB loader path. Without
      // this, IFC luminaires from the catalogue could be placed but would not
      // be recognised by LightFixtureController.
      assetCategory: options.assetCategory || null,
      isLightFixture: options.isLightFixture === true || options.assetCategory === 'lighting',
      lightEnabled: options.lightEnabled === true,
      lightIntensity: Number.isFinite(Number(options.lightIntensity)) ? Number(options.lightIntensity) : 0.12,
      lightTemperature: Number.isFinite(Number(options.lightTemperature)) ? Number(options.lightTemperature) : 4000,
      ...(options.isNativeIsolation ? { isNativeIsolation: true } : {}),
      ...(options.nativeSourceId ? { nativeSourceId: options.nativeSourceId } : {}),
      ...(options.sourceJobId ? { sourceJobId: options.sourceJobId } : {}),
      ...(options.doorHostWallId ? { doorHostWallId: options.doorHostWallId } : {}),
    };

    assetModel.on('loaded', () => {
      try {
        // Capture the model's local geometry bounds before any user transform is
        // applied. IFC resize uses these bounds to build a true oriented gizmo and
        // to keep the opposite face anchored during local-axis scaling.
        ensureIFCResizeMetadata(assetModel);

        const userScale = Array.isArray(options.scale) && options.scale.length === 3
          ? options.scale
          : [1, 1, 1];

        const safeRotation = Array.isArray(rotation) && rotation.length === 3
          ? rotation
          : [0, 0, 0];

        // Raw IFC matrices are authoritative only for native-isolated elements.
        // Standalone/catalogue IFCs (including hosted doors) persist semantic
        // target + rotation + scale. Replaying a stale model-origin matrix for
        // those assets makes them jump because their saved position is an AABB
        // floor/contact target, not the SceneModel origin translation.
        const persistedIFCMatrix = options.isNativeIsolation && isValidMatrix16(options.persistedMatrix)
          ? Array.from(options.persistedMatrix)
          : null;

        assetModel.scale = [...userScale];
        assetModel.rotation = [...safeRotation];

        if (persistedIFCMatrix) {
          // A native-isolated IFC is a full SceneModel created from the isolated IFC
          // bytes. Restore the exact runtime matrix produced by the gizmo instead of
          // rebuilding it from TRS; this preserves the pivot-correct transform.
          try { assetModel.matrix = persistedIFCMatrix; } catch (_) {}
        } else if (Array.isArray(targetPosition) && targetPosition.length === 3) {
          const aabb = assetModel.aabb;
          if (aabb && aabb.length >= 6) {
            const centerX = (aabb[0] + aabb[3]) / 2;
            const centerZ = (aabb[2] + aabb[5]) / 2;
            const bottomY = aabb[1];
            assetModel.position = [
              targetPosition[0] - centerX,
              targetPosition[1] - bottomY,
              targetPosition[2] - centerZ,
            ];
          } else {
            assetModel.position = [...targetPosition];
          }
        }

        if (typeof options.onLoaded === 'function') {
          options.onLoaded(assetModel);
        }

        assetLoadEnd({ loaded: true, format: 'ifc', modelId: assetModel.id, bytes: buffer.byteLength });
        perfLog('ASSET', 'IFC model loaded', { instanceId, modelId: assetModel.id, srcUrl, bytes: buffer.byteLength });

        if (typeof options.onPlaced === 'function') {
          const persistedTarget = Array.isArray(targetPosition) && targetPosition.length === 3
            ? [...targetPosition]
            : [...assetModel.position];
          options.onPlaced(instanceId, persistedTarget, assetModel);
        }
        readySignal.resolve(assetModel);
      } catch (error) {
        readySignal.reject(error);
        console.error('[BIM Engine] IFC asset setup failed after load:', { instanceId, srcUrl, error });
      }
    });

    assetModel.on('error', (error) => {
      readySignal.reject(error || new Error(`Failed to load IFC asset "${instanceId}".`));
      registry.delete(instanceId);
      assetLoadEnd({ loaded: false, format: 'ifc', error: error?.message || String(error) });
      console.error('[BIM Engine] IFC asset load failure:', {
        instanceId,
        srcUrl,
        error,
      });
    });

    return assetModel._hciAssetReadyPromise;
  } catch (error) {
    registry.delete(instanceId);
    assetLoadEnd({ loaded: false, format: 'ifc', error: error?.message || String(error) });
    console.error('[BIM Engine] Placement failure:', error);
    throw error;
  }
};

export const isolateAndMakeMoveable = async (ctx, entityId, onAdoptCallback, updateStructuralEdit) => {
  const {
    file: ctxFile,
    jobId: ctxJobId,
    activeProject,
    viewerRef,
    currentModelRef,
    loadersRef,
    globalScaleFactorRef,
    setSelectedAssetId,
    setSelectedObject,
  } = ctx;

  const file = ctxFile || activeProject?.file;
  const jobId = ctxJobId || activeProject?.jobId;

  if (!file || !jobId || !entityId) {
    const error = new Error('Cannot unlock native element: missing canonical project jobId or entityId.');
    console.error('[NativeEdit] Cannot unlock:', { jobId, entityId, error: error.message });
    throw error;
  }

  const isolationKey = `${jobId}:${entityId}`;
  if (nativeIsolationInFlight.has(isolationKey)) {
    console.warn('[NativeEdit] Unlock already in progress:', { jobId, entityId });
    return null;
  }
  nativeIsolationInFlight.add(isolationKey);

  try {
    const viewer = viewerRef.current;
    const originalModel = currentModelRef?.current || null;
    // Resolve/capture the main-model entity before loading another IFC with the
    // same GlobalId. The direct reference remains valid even if scene.objects
    // later indexes the isolated replacement under that id.
    const rememberedNativeEntry = ctx.rememberNativeEntity?.(entityId);
    const rememberedNativeEntity = rememberedNativeEntry?.model === originalModel
      && rememberedNativeEntry?.entity?.destroyed !== true
      ? rememberedNativeEntry.entity
      : null;
    const indexedNativeEntities = viewer
      ? Object.values(viewer.scene.objects || {}).filter((object) => (
          object?.id === entityId
          && (!originalModel || object.model === originalModel)
        ))
      : [];
    const originalNativeEntities = rememberedNativeEntity
      ? [rememberedNativeEntity]
      : indexedNativeEntities;
    if (!originalNativeEntities.length) {
      // Refuse before asking the backend to create/load an isolation when there
      // is no safe reference to the original entity. Guessing from duplicate IDs
      // after load is how unrelated walls can be hidden.
      throw new Error(`Cannot safely unlock native element ${entityId}: its main-model entity is not available.`);
    }

    console.info('[NativeEdit] Unlock request:', {
      jobId,
      entityId,
      originalModelId: originalModel?.id || null,
      capturedNativeEntityCount: originalNativeEntities.length,
    });

    const response = await fetch(
      `${API_BASE_URL}/api/elements/${encodeURIComponent(jobId)}/${encodeURIComponent(entityId)}/isolate`,
      { method: 'POST' }
    );
    const data = await response.json().catch(() => ({}));
    if (!response.ok || !data?.fileUrl) {
      throw new Error(data?.error || `Native element isolate failed (${response.status})`);
    }

    const newInstanceId = `${entityId}_isolated`;
    const metaObject = viewerRef.current?.metaScene.metaObjects[entityId];

    let resolveLoaded;
    let rejectLoaded;
    const loadedPromise = new Promise((resolve, reject) => {
      resolveLoaded = resolve;
      rejectLoaded = reject;
    });

    const isolatedModel = await loadIFCAssetIntoScene(
      loadersRef,
      globalScaleFactorRef,
      newInstanceId,
      data.fileUrl,
      null,
      [0, 0, 0],
      {
        fileType: 'ifc',
        scale: [1, 1, 1],
        onLoaded: (model) => {
          model._assetMeta = {
            ...(model._assetMeta || {}),
            isNativeIsolation: true,
            nativeSourceId: entityId,
            sourceJobId: jobId,
          };
          resolveLoaded(model);
        },
      }
    );

    if (!isolatedModel) throw new Error('Isolated IFC model could not be created.');
    if (typeof isolatedModel.on === 'function') {
      isolatedModel.on('error', (err) => rejectLoaded(err || new Error('Isolated IFC model failed to load.')));
    }
    await loadedPromise;

    // Use only the original entity captured before the duplicate-ID model
    // loaded. Never fall back to an arbitrary scene.objects entry here.
    const nativeEntitiesToHide = originalNativeEntities;
    nativeEntitiesToHide.forEach((entity) => {
      try { entity.visible = false; } catch (error) {
        console.warn('[NativeEdit] Failed to hide original native entity:', entityId, error);
      }
    });

    updateStructuralEdit?.(entityId, 'visible', null, false);

    onAdoptCallback?.(
      entityId,
      newInstanceId,
      data.fileUrl,
      metaObject?.name,
      [...(isolatedModel.position || [0, 0, 0])],
      [...(isolatedModel.rotation || [0, 0, 0])],
      [...(isolatedModel.scale || [1, 1, 1])],
      {
        isNativeIsolation: true,
        nativeSourceId: entityId,
        sourceJobId: jobId,
        matrix: isolatedModel.matrix && isolatedModel.matrix.length === 16 ? Array.from(isolatedModel.matrix) : null,
      }
    );

    if (viewer) {
      viewer.scene.setObjectsSelected(viewer.scene.selectedObjectIds, false);
      isolatedModel.selected = true;
    }

    setSelectedAssetId(newInstanceId);
    setSelectedObject({
      id: newInstanceId,
      name: metaObject?.name || 'Isolated Element',
      type: metaObject?.type || 'Generic Component',
      groupedProperties: metaObject
        ? { 'General Details': [
            { name: 'Element Name', value: metaObject.name || 'Unnamed' },
            { name: 'IFC Class', value: metaObject.type || 'Unknown' },
            { name: 'Global ID', value: metaObject.id },
          ] }
        : {},
    });

    console.info('[NativeEdit] Unlock complete:', { jobId, entityId, newInstanceId });
    return newInstanceId;
  } catch (error) {
    console.error('[BIM Engine] Isolate-and-move failure:', { jobId, entityId, error });
    throw error;
  } finally {
    nativeIsolationInFlight.delete(isolationKey);
  }
};

export const inspectNativeElement = async (activeProject, entityId) => {
  const file = activeProject?.file;
  const jobId = activeProject?.jobId;
  if (!file || !jobId || !entityId) return { error: true };

  try {
    const response = await fetch(`${API_BASE_URL}/api/elements/${jobId}/${entityId}/inspect`);
    const data = await response.json();

    if (!response.ok || data?.error) {
      return { error: true };
    }

    return data;
  } catch (error) {
    console.error('[BIM Engine] Inspect failure:', error);
    return { error: true };
  }
};

export const updateStructuralTransform = (viewerRef, entityId, transformType, axis, value) => {
  const entity = viewerRef.current?.scene.objects[entityId];
  if (!entity) return;

  if (transformType === 'scale') {
    const newScale = [...(entity.scale || [1, 1, 1])];
    newScale[axis] = value;
    entity.scale = newScale;
  } else if (transformType === 'offset') {
    const newOffset = [...(entity.offset || [0, 0, 0])];
    newOffset[axis] = value;
    entity.offset = newOffset;
  }
};

export const updateNativeOffset = (viewerRef, id, axis, value) => {
  const entity = viewerRef.current?.scene.objects[id];
  if (entity) {
      const newOffset = [...(entity.offset || [0, 0, 0])];
      newOffset[axis] = value;
      entity.offset = newOffset;
  }
};

export const updateDynamicTransform = (viewerRef, modelId, type, axis, value) => {
  const model = viewerRef.current?.scene.models[modelId];
  if (!model) return;
  if (type === 'scale') {
      const newScale = [...(model.scale || [1, 1, 1])];
      newScale[axis] = value;
      model.scale = newScale;
  } else if (type === 'rotation') {
      const newRot = [...(model.rotation || [0, 0, 0])];
      newRot[1] = value;
      model.rotation = newRot;
  } else if (type === 'position') {
      const newPos = [...(model.position || [0, 0, 0])];
      newPos[axis] = value;
      model.position = newPos;
  }
};

import { useEffect, useState } from 'react';
import { Camera, Orbit, Image as ImageIcon, Sun, Moon, X, Loader2, Clock, Download, ExternalLink, AlertCircle, Box, Layers3 } from 'lucide-react';
import { LayoutMetadataForm } from './LayoutMetadataForm';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000';

export const RenderStudioModal = ({
  show, onClose, renderConfig, setRenderConfig, onExecute,
  isRendering, renderResult, renderTime, renderError, setRenderResult, setRenderError,
  onSaveAsLayout,
  onUpdateSavedLayoutSnapshot,
  currentSavedLayout = null,
  activeFileName = '',
  existingSavedLayouts = [],
}) => {
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadError, setDownloadError] = useState(null);
  const [showLayoutForm, setShowLayoutForm] = useState(false);
  const [isSavingLayout, setIsSavingLayout] = useState(false);
  const [saveLayoutMessage, setSaveLayoutMessage] = useState(null);

  useEffect(() => {
    if (!show) {
      setShowLayoutForm(false);
      setSaveLayoutMessage(null);
      setIsSavingLayout(false);
    }
  }, [show]);

  if (!show) return null;

  const jobId = renderResult?.jobId;
  const walkthroughUrl = renderResult?.walkthroughUrl || (jobId ? `${window.location.origin}/walkthrough/${encodeURIComponent(jobId)}` : null);
  const modelUrl = renderResult?.modelUrl || (jobId ? `${API_BASE_URL}/jobs/${encodeURIComponent(jobId)}/output.glb` : null);

  // Saved layouts have durable presentation metadata, so the render header should
  // identify the design humans selected instead of exposing an internal render job id.
  // For a normal project/render, fall back to its IFC filename.
  const savedLayoutTitle = currentSavedLayout
    ? [currentSavedLayout.categoryName, currentSavedLayout.subCategory, currentSavedLayout.name]
        .map((value) => String(value || '').trim())
        .filter(Boolean)
        .join(' → ')
    : '';
  const renderDisplayName = savedLayoutTitle || String(activeFileName || '').trim() || jobId || 'HCI model';

  const handleSaveAsLayout = async (metadata) => {
    if (!onSaveAsLayout || isSavingLayout) return;
    setIsSavingLayout(true);
    setSaveLayoutMessage(null);
    try {
      await onSaveAsLayout(metadata, renderResult, renderConfig);
      setSaveLayoutMessage({ type: 'success', text: `Saved “${metadata.name}” to Layouts.` });
      setShowLayoutForm(false);
    } catch (error) {
      setSaveLayoutMessage({ type: 'error', text: error.message || 'Failed to save this layout.' });
    } finally {
      setIsSavingLayout(false);
    }
  };

  const handleUpdateSavedLayout = async () => {
    if (!onUpdateSavedLayoutSnapshot || !currentSavedLayout?.id || isSavingLayout) return;
    setIsSavingLayout(true);
    setSaveLayoutMessage(null);
    try {
      const updatedLayout = await onUpdateSavedLayoutSnapshot(currentSavedLayout.id, renderResult, renderConfig);
      const nextWalkthroughUrl = updatedLayout.walkthroughUrl || walkthroughUrl;
      const nextModelUrl = updatedLayout.modelUrl || modelUrl;
      setRenderResult?.((previous) => previous ? ({
        ...previous,
        // Keep jobId tied to the active working project: the update API reads
        // its fresh output.glb from that job. Track the immutable snapshot id
        // separately so a second update cannot accidentally use the snapshot as
        // the mutable source project.
        renderJobId: updatedLayout.renderJobId || previous.renderJobId || null,
        modelUrl: nextModelUrl,
        walkthroughUrl: nextWalkthroughUrl,
        isSavedLayout: true,
      }) : previous);
      setSaveLayoutMessage({ type: 'success', text: `Updated “${updatedLayout.name}”.` });
    } catch (error) {
      setSaveLayoutMessage({ type: 'error', text: error.message || 'Failed to update this layout.' });
    } finally {
      setIsSavingLayout(false);
    }
  };

  const downloadModel = async () => {
    if (!modelUrl || isDownloading) return;
    setIsDownloading(true);
    setDownloadError(null);
    try {
      const response = await fetch(modelUrl, { cache: 'no-store' });
      if (!response.ok) throw new Error(`Model download failed (${response.status}).`);
      const blob = await response.blob();
      const objectUrl = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = objectUrl;
      anchor.download = `${jobId || 'hci-model'}.glb`;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      window.setTimeout(() => URL.revokeObjectURL(objectUrl), 5000);
    } catch (error) {
      setDownloadError(error.message || 'Unable to download the model.');
    } finally {
      setIsDownloading(false);
    }
  };

  if (isRendering) return (
    <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex flex-col items-center justify-center text-white">
      <Loader2 className="w-16 h-16 animate-spin text-indigo-500 mb-6" />
      <h2 className="text-3xl font-bold mb-2">Preparing Interactive Home Presentation...</h2>
      <p className="text-slate-300">Preparing the walkthrough scene and reusing valid cached assets where possible.</p>
      <p className="text-slate-400 text-sm mt-2">Unchanged scenes can be reused; finish-only edits can reuse navigation data. Geometry changes still need a fresh navigation build.</p>
    </div>
  );

  if (renderResult) return (
    <div className="absolute inset-0 bg-slate-900/90 backdrop-blur-md z-[100] flex flex-col items-center justify-center p-8">
      <div className="w-full max-w-6xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl overflow-hidden flex flex-col" style={{ height: '86vh' }}>
        <div className="flex justify-between items-center p-4 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <div>
              <h3 className="font-bold text-lg text-slate-800 dark:text-white">Interactive Home Presentation</h3>
              <p
                className="mt-0.5 max-w-[760px] break-words text-xs font-medium leading-5 text-slate-400"
                title={renderDisplayName}
              >
                {renderDisplayName}
              </p>
            </div>
            <span className="text-sm text-emerald-600 dark:text-emerald-400 flex items-center gap-1 bg-emerald-50 dark:bg-emerald-500/10 px-3 py-1 rounded-full"><Clock className="w-4 h-4"/> {renderTime}s</span>
            {renderResult?.cacheHit && (
              <span title="The exact scene inputs were unchanged; the previous compiled presentation was reused." className="rounded-full bg-sky-50 px-3 py-1 text-xs font-semibold text-sky-700 dark:bg-sky-500/10 dark:text-sky-300">Instant cached build</span>
            )}
            {!renderResult?.cacheHit && renderResult?.navigationCacheHit && (
              <span title="Furniture/materials were recompiled, but the scene geometry was unchanged so navigation data was reused." className="rounded-full bg-violet-50 px-3 py-1 text-xs font-semibold text-violet-700 dark:bg-violet-500/10 dark:text-violet-300">Navigation reused</span>
            )}
          </div>
          <button onClick={() => setRenderResult(null)} className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400"><X className="w-6 h-6" /></button>
        </div>

        <div className="flex-1 bg-slate-100 dark:bg-[#0b0f1a] relative p-3">
          {renderConfig.type === '360' ? (
            <iframe
              src={walkthroughUrl}
              className="w-full h-full rounded-xl border-2 border-slate-200 dark:border-slate-700 shadow-inner bg-black"
              allowFullScreen
              title="HCI Interactive 360 Walkthrough"
            />
          ) : (
            <img src={renderResult.url} alt="Render Output" className="max-w-full max-h-full mx-auto rounded-xl shadow-2xl object-contain" />
          )}
        </div>

        <div className="p-4 border-t border-slate-200 dark:border-slate-800 flex flex-wrap justify-end items-center gap-3 bg-slate-50 dark:bg-slate-800/50">
          {renderConfig.type === '360' ? (
            <>
              {currentSavedLayout?.id && onUpdateSavedLayoutSnapshot ? (
                <>
                  <div className="flex w-full items-center gap-3 rounded-xl border border-emerald-200/80 bg-emerald-50/60 p-3 dark:border-emerald-900/50 dark:bg-emerald-950/20 lg:w-auto">
                    <div className="hidden sm:flex h-9 w-9 items-center justify-center rounded-lg bg-white text-emerald-600 shadow-sm dark:bg-slate-900">
                      <Layers3 className="h-4 w-4" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-bold text-slate-800 dark:text-white">Update saved layout</p>
                      <p className="mt-0.5 max-w-[260px] truncate text-[10px] text-slate-500 dark:text-slate-400">{currentSavedLayout.name} · save the current design as its latest version.</p>
                    </div>
                    <button
                      type="button"
                      onClick={handleUpdateSavedLayout}
                      disabled={isSavingLayout}
                      className="shrink-0 rounded-lg bg-[#ff914d] px-4 py-2.5 text-xs font-bold text-white transition hover:bg-[#ff7a28] disabled:cursor-wait disabled:opacity-60"
                    >
                      {isSavingLayout ? 'Updating…' : 'Update Layout'}
                    </button>
                    {saveLayoutMessage && <span className={`hidden max-w-[220px] text-[11px] sm:block ${saveLayoutMessage.type === 'success' ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}`}>{saveLayoutMessage.text}</span>}
                  </div>
                  {onSaveAsLayout && (
                    <button
                      type="button"
                      onClick={() => { setSaveLayoutMessage(null); setShowLayoutForm(true); }}
                      disabled={isSavingLayout}
                      className="shrink-0 rounded-xl border border-indigo-200 bg-indigo-50/70 px-4 py-3 text-xs font-bold text-indigo-600 transition hover:border-indigo-300 hover:bg-indigo-100 disabled:cursor-wait disabled:opacity-60 dark:border-indigo-900/60 dark:bg-indigo-950/20 dark:text-indigo-300 dark:hover:bg-indigo-950/40"
                    >
                      Save as New Layout
                    </button>
                  )}
                </>
              ) : onSaveAsLayout ? (
                <div className="flex w-full items-center gap-3 rounded-xl border border-indigo-200/80 bg-indigo-50/60 p-3 dark:border-indigo-900/50 dark:bg-indigo-950/25 lg:w-auto">
                  <div className="hidden sm:flex h-9 w-9 items-center justify-center rounded-lg bg-white text-indigo-500 shadow-sm dark:bg-slate-900">
                    <Layers3 className="h-4 w-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-bold text-slate-800 dark:text-white">Save this render as a reusable layout</p>
                    <p className="mt-0.5 text-[10px] text-slate-500 dark:text-slate-400">Choose category → sub-category → layout name.</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => { setSaveLayoutMessage(null); setShowLayoutForm(true); }}
                    disabled={isSavingLayout}
                    className="shrink-0 rounded-lg bg-[#ff914d] px-4 py-2.5 text-xs font-bold text-white transition hover:bg-[#ff7a28] disabled:cursor-wait disabled:opacity-60"
                  >
                    Save as Layout
                  </button>
                  {saveLayoutMessage && <span className={`hidden max-w-[220px] text-[11px] sm:block ${saveLayoutMessage.type === 'success' ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}`}>{saveLayoutMessage.text}</span>}
                </div>
              ) : null}
              <button
                type="button"
                onClick={downloadModel}
                disabled={!modelUrl || isDownloading}
                className="flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg font-semibold transition-colors"
              >
                {isDownloading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
                {isDownloading ? 'Preparing…' : 'Download 3D Model (.glb)'}
              </button>
              <a
                href={walkthroughUrl || '#'}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-2 px-5 py-2.5 bg-slate-800 hover:bg-slate-900 dark:bg-slate-700 dark:hover:bg-slate-600 text-white rounded-lg font-semibold transition-colors"
              >
                <ExternalLink className="w-4 h-4" /> Open Presentation Fullscreen
              </a>
              {downloadError && <span className="w-full text-right text-xs text-rose-500">{downloadError}</span>}
            </>
          ) : (
            <a href={renderResult.url} download target="_blank" rel="noreferrer" className="flex items-center gap-2 px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-semibold transition-colors">
              <Download className="w-4 h-4" /> Download Image
            </a>
          )}
        </div>
      {showLayoutForm && (
        <div className="absolute inset-0 z-[140] flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-md">
          <div className="flex max-h-[85vh] w-full max-w-2xl flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl dark:border-slate-700 dark:bg-slate-900">
            <div className="shrink-0 border-b border-slate-200 p-5 dark:border-slate-800">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-indigo-500">Save Layout</p>
                <h3 className="mt-1 text-lg font-bold text-slate-900 dark:text-white">Organize this layout</h3>
                <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">The snapshot keeps the IFC and all scene edits exactly as rendered.</p>
              </div>
              <button type="button" onClick={() => setShowLayoutForm(false)} className="rounded-lg p-2 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-white/5 dark:hover:text-white" aria-label="Close save layout form">
                <X className="h-5 w-5" />
              </button>
            </div>
            </div>
            <div className="min-h-0 flex-1 overflow-y-auto p-5">
            <LayoutMetadataForm
              mode="create"
              fileName={activeFileName}
              existingLayouts={existingSavedLayouts}
              submitting={isSavingLayout}
              onSubmit={handleSaveAsLayout}
              onCancel={() => setShowLayoutForm(false)}
            />
            </div>
          </div>
        </div>
      )}
      </div>
    </div>
  );

  if (renderError) return (
    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-[100] w-96 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-rose-200 dark:border-rose-900 overflow-hidden animate-in fade-in zoom-in-95 duration-300">
      <div className="p-6 text-center">
        <div className="w-16 h-16 bg-rose-100 dark:bg-rose-900/30 text-rose-500 rounded-full flex items-center justify-center mx-auto mb-4"><AlertCircle className="w-8 h-8" /></div>
        <h3 className="text-xl font-bold text-slate-800 dark:text-white mb-2">Render Failed</h3>
        <p className="text-slate-500 dark:text-slate-400 text-sm mb-6">{renderError}</p>
        <button onClick={() => setRenderError(null)} className="w-full py-3 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-white rounded-xl font-semibold transition-colors">Dismiss</button>
      </div>
    </div>
  );

  return (
    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-[100] w-96 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden animate-in fade-in zoom-in-95 duration-300">
      <div className="p-5 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 flex justify-between items-center">
        <div className="flex items-center gap-2"><Camera className="w-5 h-5 text-indigo-500" /><h3 className="font-bold text-slate-800 dark:text-white">Render Studio</h3></div>
        <button onClick={onClose} className="text-slate-400 hover:text-slate-600 dark:hover:text-white"><X className="w-5 h-5" /></button>
      </div>

      <div className="p-6 space-y-6">
        <div>
          <label className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 block">Output Type</label>
          <div className="grid grid-cols-2 gap-3">
            <button onClick={() => setRenderConfig({ ...renderConfig, type: '360' })} className={`py-3 rounded-xl border flex flex-col items-center gap-2 transition-all ${renderConfig.type === '360' ? 'bg-indigo-50 border-indigo-500 text-indigo-600 dark:bg-indigo-900/30 dark:border-indigo-500 dark:text-indigo-400' : 'bg-white border-slate-200 text-slate-600 hover:border-indigo-300 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-400'}`}><Orbit className="w-5 h-5" /><span className="text-sm font-semibold">360° walkthrough</span></button>
            <button onClick={() => setRenderConfig({ ...renderConfig, type: 'static' })} className={`py-3 rounded-xl border flex flex-col items-center gap-2 transition-all ${renderConfig.type === 'static' ? 'bg-indigo-50 border-indigo-500 text-indigo-600 dark:bg-indigo-900/30 dark:border-indigo-500 dark:text-indigo-400' : 'bg-white border-slate-200 text-slate-600 hover:border-indigo-300 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-400'}`}><ImageIcon className="w-5 h-5" /><span className="text-sm font-semibold">4K still image</span></button>
          </div>
        </div>

        {renderConfig.type === 'static' ? (
          <div>
            <label className="mb-3 block text-xs font-bold uppercase tracking-wider text-slate-400">Image lighting</label>
            <div className="grid grid-cols-2 gap-3">
              <button type="button" onClick={() => setRenderConfig({ ...renderConfig, lighting: 'daylight' })} aria-pressed={renderConfig.lighting === 'daylight'} className={`flex flex-col items-center gap-2 rounded-xl border py-3 transition-all ${renderConfig.lighting === 'daylight' ? 'border-amber-500 bg-amber-50 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300' : 'border-slate-200 bg-white text-slate-600 hover:border-amber-300 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-400'}`}>
                <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300"><Sun className="h-4.5 w-4.5" /></span>
                <span className="text-sm font-semibold">Daylight</span>
              </button>
              <button type="button" onClick={() => setRenderConfig({ ...renderConfig, lighting: 'night' })} aria-pressed={renderConfig.lighting === 'night'} className={`flex flex-col items-center gap-2 rounded-xl border py-3 transition-all ${renderConfig.lighting === 'night' ? 'border-indigo-500 bg-indigo-50 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-300' : 'border-slate-200 bg-white text-slate-600 hover:border-indigo-300 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-400'}`}>
                <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-indigo-100 text-indigo-700 dark:bg-indigo-500/15 dark:text-indigo-300"><Moon className="h-4.5 w-4.5" /></span>
                <span className="text-sm font-semibold">Nighttime</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="flex items-start gap-3 rounded-xl border border-indigo-100 bg-indigo-50/70 p-3 dark:border-indigo-900/40 dark:bg-indigo-950/30">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-indigo-100 text-indigo-700 dark:bg-indigo-500/15 dark:text-indigo-300"><Orbit className="h-4.5 w-4.5" /></span>
            <div>
              <p className="text-xs font-bold text-slate-800 dark:text-slate-100">Set the mood inside the walkthrough</p>
              <p className="mt-1 text-[11px] leading-4 text-slate-600 dark:text-slate-300">Choose day, evening or night lighting from the walkthrough controls after opening the 360° experience.</p>
            </div>
          </div>
        )}

        <div className="rounded-xl border border-indigo-100 dark:border-indigo-900/40 bg-indigo-50/70 dark:bg-indigo-950/30 p-3 text-xs text-slate-600 dark:text-slate-300 flex gap-2">
          <Box className="mt-0.5 w-4 h-4 shrink-0 text-indigo-500" />
          <span>Interactive 360° uses the final React walkthrough. After rendering, the final compiled GLB can be downloaded for local use.</span>
        </div>

        <button onClick={onExecute} className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-lg shadow-lg shadow-indigo-600/30 transition-all active:scale-[0.98] flex items-center justify-center gap-2"><Camera className="w-5 h-5" /> Start Render</button>
      </div>
    </div>
  )
};
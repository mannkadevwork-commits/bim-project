import { useState, useEffect, useRef } from 'react';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000';

// ── PREDEFINED ROOM LAYOUTS ─────────────────────────────
// Users can inject these specific room setups into their 1 BHK / 3 BHK empty structures
const MOCK_ROOM_TEMPLATES = [
  {
    id: 'room_master_bedroom',
    name: 'Master Bedroom Setup',
    description: 'Double bed with wardrobes and side tables.',
    items: [
      { id: 'bed_double', name: 'Master Bed', url: '/assets/bed_master.ifc', position: [2, 0, -3], rotation: [0, 90, 0] },
      { id: 'wardrobe', name: 'Wardrobe', url: '/assets/wardrobe.ifc', position: [4, 0, -3], rotation: [0, 0, 0] },
      { id: 'side_table', name: 'Side Table', url: '/assets/side_table.ifc', position: [2, 0, -1.5], rotation: [0, 0, 0] },
    ]
  },
  {
    id: 'room_living',
    name: 'Living Room Setup',
    description: 'Sofa set, center table, and TV unit.',
    items: [
      { id: 'sofa_3seater', name: 'Main Sofa', url: '/assets/sofa.ifc', position: [-2, 0, 2], rotation: [0, 0, 0] },
      { id: 'tv_unit', name: 'TV Unit', url: '/assets/tv_unit.ifc', position: [-2, 0, 5], rotation: [0, 180, 0] },
      { id: 'coffee_table', name: 'Coffee Table', url: '/assets/coffee_table.ifc', position: [-1, 0, 3.5], rotation: [0, 0, 0] },
    ]
  }
];

export const useProjectSync = (file) => {
  const [projectState, setProjectState] = useState({ materials: {}, furniture: [], structural_edits: {} });
  const projectStateRef = useRef(projectState);

  const [availableAssets, setAvailableAssets] = useState([]);
  const [homeTemplates, setHomeTemplates] = useState(MOCK_ROOM_TEMPLATES); // Renamed conceptually
  const [saveStatus, setSaveStatus] = useState('saved');
  const [lastSavedTime, setLastSavedTime] = useState(null);
  const [toastMessage, setToastMessage] = useState(null);
  const activeJobId = useRef('job_default_01');
  const [customColor, setCustomColor] = useState('#ffffff');

  const [isStateReady, setIsStateReady] = useState(false);

  useEffect(() => { projectStateRef.current = projectState; }, [projectState]);

  // LOAD: Fetch initial project state & asset catalog on startup
  useEffect(() => {
    if (file) {
      // 1. Lock the 3D engine from starting
      setIsStateReady(false);
      
      // 2. Synchronously wipe the memory completely to prevent race condition leaks
      const emptyState = { materials: {}, furniture: [], structural_edits: {} };
      setProjectState(emptyState);
      projectStateRef.current = emptyState; 
      
      activeJobId.current = `job_${file.name.replace(/[^a-zA-Z0-9]/g, '_')}`;
      const localState = localStorage.getItem(`hci_state_${activeJobId.current}`);
      
      if (localState) {
        try {
          const parsed = JSON.parse(localState);
          const newState = { structural_edits: {}, ...parsed };
          setProjectState(newState);
          projectStateRef.current = newState; // Ensure ref is ready immediately
        } catch (e) {
          console.warn('[ProjectSync] Failed to parse local state, starting fresh.');
        }
        setIsStateReady(true); // Unlock engine
      } else {
        // Use a cache-buster timestamp to ensure deleted files aren't fetched from browser cache
        fetch(`${API_BASE_URL}/api/projects/${activeJobId.current}/load?t=${Date.now()}`)
          .then(res => res.ok ? res.json() : null)
          .then(data => {
            if (
              data &&
              (Object.keys(data.materials || {}).length > 0 ||
                (data.furniture || []).length > 0 ||
                Object.keys(data.structural_edits || {}).length > 0)
            ) {
              const newState = { structural_edits: {}, ...data };
              setProjectState(newState);
              projectStateRef.current = newState;
            }
            setIsStateReady(true); // Unlock engine
          })
          .catch(() => {
            console.warn('[ProjectSync] No previous cloud state found, starting fresh.');
            setIsStateReady(true); // Unlock engine even if failed, so it loads the blank IFC
          });
      }
    } else {
      // Wipes memory when file is deleted
      const emptyState = { materials: {}, furniture: [], structural_edits: {} };
      setProjectState(emptyState);
      projectStateRef.current = emptyState;
      setIsStateReady(false);
    }

    fetch(`${API_BASE_URL}/api/assets?t=${Date.now()}`)
      .then(res => res.json())
      .then(data => setAvailableAssets(data))
      .catch(err => console.error('[ProjectSync] Failed to load asset catalog:', err));
  }, [file]);

  // ─────────────────────────────────────────────────────────────
  // AUTO-SAVE: Debounced save to localStorage + cloud
  // ─────────────────────────────────────────────────────────────
  useEffect(() => {
    // If state is completely empty, do not overwrite valid saves (prevents wiping on boot)
    if (
      Object.keys(projectState.materials).length === 0 &&
      projectState.furniture.length === 0 &&
      Object.keys(projectState.structural_edits || {}).length === 0
    ) return;

    setSaveStatus('unsaved');
    localStorage.setItem(`hci_state_${activeJobId.current}`, JSON.stringify(projectState));

    const delayCloudSave = setTimeout(async () => {
      setSaveStatus('saving');
      try {
        await fetch(`${API_BASE_URL}/api/projects/${activeJobId.current}/save`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(projectState),
        });
        setSaveStatus('saved');
        setLastSavedTime(new Date());
      } catch (err) {
        console.error('[ProjectSync] Cloud auto-save failed:', err);
        setSaveStatus('error');
      }
    }, 1500);

    return () => clearTimeout(delayCloudSave);
  }, [projectState]);

  // ─────────────────────────────────────────────────────────────
  // ACTION: Apply material color to a selected building element
  // ─────────────────────────────────────────────────────────────
  const applyMaterial = (viewerRef, selectedObject, hexColor, rgbArray) => {
    if (!selectedObject || !viewerRef.current) return;
    const entity = viewerRef.current.scene.objects[selectedObject.id];
    if (entity) entity.colorize = rgbArray;
    setCustomColor(hexColor);
    setProjectState(prev => ({
      ...prev,
      materials: {
        ...prev.materials,
        [selectedObject.id]: { color: hexColor, rgb: rgbArray },
      },
    }));
  };

  // ─────────────────────────────────────────────────────────────
  // ACTION: Update asset transform (Position, Scale, Rotation)
  // ─────────────────────────────────────────────────────────────
  const updateAsset = (viewerRef, selectedAssetId, axis, value, isRotation = false, isScale = false) => {
    if (!selectedAssetId || !viewerRef.current) return;
    const assetModel = viewerRef.current.scene.models[selectedAssetId];
    if (!assetModel) return;

    const numValue = parseFloat(value);
    let updatedPos, updatedRot, updatedScale;

    if (isScale) {
      updatedScale = [...(assetModel.scale || [1, 1, 1])];
      updatedScale[axis] = numValue;
      assetModel.scale = updatedScale;
    } else if (isRotation) {
      updatedRot = [...(assetModel.rotation || [0, 0, 0])];
      updatedRot[axis] = numValue;
      assetModel.rotation = updatedRot;
    } else {
      updatedPos = [...(assetModel.position || [0, 0, 0])];
      updatedPos[axis] = numValue;
      assetModel.position = updatedPos;
    }

    setProjectState(prev => ({
      ...prev,
      furniture: prev.furniture.map(f =>
        f.instanceId === selectedAssetId
          ? { 
              ...f, 
              position: updatedPos || f.position, 
              rotation: updatedRot || f.rotation,
              scale: updatedScale || f.scale
            }
          : f
      ),
    }));
  };

  // ─────────────────────────────────────────────────────────────
  // ACTION: Delete a furniture asset from the scene
  // ─────────────────────────────────────────────────────────────
  const deleteAsset = (viewerRef, selectedAssetId) => {
    if (!selectedAssetId || !viewerRef.current) return;
    const assetModel = viewerRef.current.scene.models[selectedAssetId];
    if (assetModel) {
      assetModel.destroy();
      setProjectState(prev => ({
        ...prev,
        furniture: prev.furniture.filter(f => f.instanceId !== selectedAssetId),
      }));
    }
    setToastMessage('Asset removed.');
    setTimeout(() => setToastMessage(null), 3000);
  };

  // ─────────────────────────────────────────────────────────────
  // ACTION: Apply Predefined Room Layout (Batch load furniture)
  // ─────────────────────────────────────────────────────────────
  const applyTemplate = (templateId, loadIFCAssetIntoScene) => {
    const template = homeTemplates.find(t => t.id === templateId);
    if (!template) return;

    const newFurnitureItems = template.items.map(item => {
      // Generate unique ID for the instanced asset
      const uniqueId = `${item.id}_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
      const fullAssetUrl = item.url.startsWith('http') ? item.url : `${API_BASE_URL}${item.url}`;

      // Trigger the 3D Engine to load the asset at the predefined coordinates
      loadIFCAssetIntoScene(uniqueId, fullAssetUrl, item.position, item.rotation);

      return {
        id: item.id,
        instanceId: uniqueId,
        name: item.name,
        src: fullAssetUrl,
        position: item.position,
        rotation: item.rotation,
      };
    });

    // Save batch into project state
    setProjectState(prev => ({
      ...prev,
      furniture: [...prev.furniture, ...newFurnitureItems],
    }));

    setToastMessage(`${template.name} Applied!`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // ─────────────────────────────────────────────────────────────
  // ACTION: Spawn a single asset (Drag & Drop or Click)
  // ─────────────────────────────────────────────────────────────
  const spawnAsset = (asset, coordinates, loadIFCAssetIntoScene, rotation = [0, 0, 0]) => {
    const uniqueId = `${asset.id}_${Date.now()}`;
    const urlPath = asset.url || asset.src || `/assets/${asset.id}.ifc`;
    const fullAssetUrl = urlPath.startsWith('http')
      ? urlPath                         
      : `${API_BASE_URL}${urlPath}`;    

      // --- ADD THESE LOGS ---
    console.log("--- STATE SYNC DEBUG ---");
    console.log("Furniture ID:", uniqueId);
    console.log("Position saved to State:", coordinates);
    // ----------------------

    setProjectState(prev => ({
      ...prev,
      furniture: [
        ...prev.furniture,
        {
          id: asset.id,
          instanceId: uniqueId,
          name: asset.name,
          src: fullAssetUrl,
          position: coordinates,
          rotation: rotation,
        },
      ],
    }));

    loadIFCAssetIntoScene(uniqueId, fullAssetUrl, coordinates, rotation);

    setToastMessage(`${asset.name} placed!`);
    setTimeout(() => setToastMessage(null), 3000);
  };


  // ─────────────────────────────────────────────────────────────
  // ACTION: Record a structural (parametric resize) edit for a native
  // IFC element. This is Delta-Based State Management — input.ifc is
  // never rewritten. We only ever persist a scale ratio / offset delta
  // per element, and re-apply it visually on load.
  // ─────────────────────────────────────────────────────────────
  // const updateStructuralEdit = (entityId, transformType, axis, value) => {
  //   if (!entityId) return;
  //   if (transformType !== 'scale' && transformType !== 'offset') {
  //     console.warn(`[ProjectSync] Unknown structural edit type: ${transformType}`);
  //     return;
  //   }

  //   setProjectState(prev => {
  //     const existingEdit = prev.structural_edits[entityId] || { scale: [1, 1, 1], offset: [0, 0, 0] };
  //     const defaultVector = transformType === 'scale' ? [1, 1, 1] : [0, 0, 0];
  //     const updatedVector = [...(existingEdit[transformType] || defaultVector)];
  //     updatedVector[axis] = value;

  //     return {
  //       ...prev,
  //       structural_edits: {
  //         ...prev.structural_edits,
  //         [entityId]: {
  //           ...existingEdit,
  //           [transformType]: updatedVector,
  //         },
  //       },
  //     };
  //   });
  // };


  const updateStructuralEdit = (entityId, transformType, axis, value) => {
    if (!entityId) return;
    if (transformType !== 'scale' && transformType !== 'offset' && transformType !== 'visible') {
      console.warn(`[ProjectSync] Unknown structural edit type: ${transformType}`);
      return;
    }

    setProjectState(prev => {
      const existingEdit = prev.structural_edits[entityId] || { scale: [1, 1, 1], offset: [0, 0, 0], visible: true };
      
      // Handle direct visibility overrides
      if (transformType === 'visible') {
          return {
            ...prev,
            structural_edits: {
              ...prev.structural_edits,
              [entityId]: { ...existingEdit, visible: value },
            },
          };
      }

      const defaultVector = transformType === 'scale' ? [1, 1, 1] : [0, 0, 0];
      const updatedVector = [...(existingEdit[transformType] || defaultVector)];
      if (axis !== null) updatedVector[axis] = value;

      return {
        ...prev,
        structural_edits: {
          ...prev.structural_edits,
          [entityId]: {
            ...existingEdit,
            [transformType]: updatedVector,
          },
        },
      };
    });
  };

  // ─────────────────────────────────────────────────────────────
// ACTION: Adopt a freshly-isolated native IFC element into furniture state
// ─────────────────────────────────────────────────────────────
const adoptIsolatedAsset = (entityId, newInstanceId, fileUrl, assetName) => {
  setProjectState(prev => ({
    ...prev,
    furniture: [
      ...prev.furniture,
      {
        id: entityId,
        instanceId: newInstanceId,
        name: assetName || 'Isolated Element',
        src: fileUrl,
        position: [0, 0, 0],
        rotation: [0, 0, 0],
        scale: [1, 1, 1],
      },
    ],
  }));
};
  return {
    projectState,
    projectStateRef,
    saveStatus,
    lastSavedTime,
    isStateReady,
    availableAssets,
    homeTemplates, // Bound to the "Layouts" tab in LeftPanel
    toastMessage,
    customColor,
    applyMaterial,
    updateAsset,
    deleteAsset,
    spawnAsset,
    applyTemplate,
    adoptIsolatedAsset,
    updateStructuralEdit,
    setToastMessage,
    setCustomColor,
  };
};
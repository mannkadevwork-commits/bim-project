import { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import BIMViewer from './BIMViewer';
import AdminPanel from './pages/AdminPanel';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import UploadModal from './components/UploadModal';
import ContactForm from './components/ContactForm';
import { AlertTriangle } from 'lucide-react';

function ViewerApp() {
  const [isUploadOpen, setIsUploadOpen] = useState(true);
  const [isContactOpen, setIsContactOpen] = useState(false);
  
  // NEW: Canonical project state holding { jobId, file, fileName }
  const [activeProject, setActiveProject] = useState(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);

  // Resume active project on refresh
  useEffect(() => {
    const resumeProject = async () => {
      const saved = localStorage.getItem('hci_active_project');
      if (saved) {
        try {
          const { jobId, fileName } = JSON.parse(saved);
          const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000';
          
          // Reconstruct the File object from the backend's original IFC copy
          const res = await fetch(`${API_BASE_URL}/jobs/${jobId}/original.ifc`);
          if (!res.ok) throw new Error('Could not fetch original ifc from backend');
          
          const blob = await res.blob();
          const file = new File([blob], fileName, { type: 'application/octet-stream' });
          
          setActiveProject({ jobId, file, fileName });
          setIsUploadOpen(false);
        } catch (err) {
          console.error("[App] Failed to resume project. Starting fresh.", err);
          localStorage.removeItem('hci_active_project');
        }
      }
    };
    resumeProject();
  }, []);

  const handleProjectUpload = (projectData) => {
    setActiveProject(projectData);
    localStorage.setItem('hci_active_project', JSON.stringify({
      jobId: projectData.jobId,
      fileName: projectData.fileName
    }));
    setIsUploadOpen(false);
  };

  const handleDeleteRequest = () => {
    setIsDeleteModalOpen(true);
  };

  const confirmDelete = async () => {
    if (activeProject) {
      const { jobId, fileName } = activeProject;
      localStorage.removeItem(`hci_state_${jobId}`);
      
      const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000';
      try {
        const res = await fetch(`${API_BASE_URL}/api/projects/${jobId}`, {
          method: 'DELETE'
        });
        const data = await res.json();
        
        // Use the newJobId provided by the backend to reset the workspace safely
        if (data.success && data.newJobId) {
          const resIfc = await fetch(`${API_BASE_URL}/jobs/${data.newJobId}/original.ifc`);
          const blob = await resIfc.blob();
          const file = new File([blob], fileName, { type: 'application/octet-stream' });
          
          setActiveProject({ jobId: data.newJobId, file, fileName });
          localStorage.setItem('hci_active_project', JSON.stringify({
            jobId: data.newJobId,
            fileName: fileName
          }));
        } else {
           throw new Error("Backend did not return newJobId");
        }
      } catch (err) {
        console.error("Failed to delete project on backend:", err);
        setActiveProject(null);
        localStorage.removeItem('hci_active_project');
        setIsUploadOpen(true);
      }
    }
    setIsDeleteModalOpen(false);
  };

  return (
    <div className="relative w-screen h-screen bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-50 transition-colors duration-300 overflow-hidden flex flex-col">
      {!activeProject && (
        <Navbar
          onOpenUpload={() => setIsUploadOpen(true)}
          onOpenContact={() => setIsContactOpen(true)}
        />
      )}

      <div className="flex-1 relative h-full">
        <BIMViewer
          activeProject={activeProject}
          onDelete={handleDeleteRequest} 
          onAdd={() => setIsUploadOpen(true)}
        />
      </div>

      {!activeProject && <Footer />}

      <UploadModal
        isOpen={isUploadOpen}
        onClose={() => { if (activeProject) setIsUploadOpen(false); }}
        onProjectCreated={handleProjectUpload}
      />

      <ContactForm
        isOpen={isContactOpen}
        onClose={() => setIsContactOpen(false)}
      />

      {isDeleteModalOpen && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-slate-900/50 backdrop-blur-sm">
          <div className="bg-white dark:bg-slate-900 w-full max-w-md p-6 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-start gap-4 mb-4">
              <div className="w-12 h-12 rounded-full bg-rose-100 dark:bg-rose-900/30 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-6 h-6 text-rose-600 dark:text-rose-400" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white">Delete Current Project?</h3>
                <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
                  This will remove the current structural layout and clear all placed furniture and unsaved progress from your browser. This action cannot be undone.
                </p>
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button 
                onClick={() => setIsDeleteModalOpen(false)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={confirmDelete}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-semibold transition-colors shadow-sm"
              >
                Yes, Delete Project
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<ViewerApp />} />
        <Route path="/admin" element={<AdminPanel />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;